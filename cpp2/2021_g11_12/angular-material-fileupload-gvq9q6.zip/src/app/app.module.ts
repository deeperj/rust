import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import {DemoMaterialModule} from './demo-material.module'
import { AppComponent } from './app.component';
import { HelloComponent } from './hello.component';
import { FileuploadComponent } from './widgets/fileupload.component';

@NgModule({
  imports:      [ BrowserModule, FormsModule, DemoMaterialModule ],
  declarations: [ AppComponent, HelloComponent,FileuploadComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
