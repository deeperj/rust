#ifndef PUZZLE_H
#define PUZZLE_H

#include <iostream>
#include <ctime>
#include "Test.h"

using std::cout;
using std::cin;
using std::endl;

const int BSZ=3;
const int BSZ2=BSZ*BSZ;

class PuzzleGame{
private:
  int choice,idv,id0;
  bool winner;
  void checkChoice();
  void swapPiece();
  void drawBoard();
  void randomizeBoard();
  bool checkWin();
  void getChoice();
  int find(int sval);
public:
  friend class Test;
  int board[BSZ2]={1, 4, 2, 6, 0, 5, 7, 3, 8};
  PuzzleGame(){};
  void startGame();
};

#endif