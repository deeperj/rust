#ifndef TEST_H
#define TEST_H

#include <assert.h>

using std::cout;
using std::endl;
using std::string;

//  typedef void (Test::*Spec1)(); //= &Target1::Method;
//  (target.*oneParam)(1);
// typedef void (*Spec2)(int);

class AssertErr{};
class PuzzleGame;
class Test{
	private:
		bool ok;
    PuzzleGame *game;
    void testFind2();
  public:
    Test();
    ~Test();
		void testall();
		bool getOk();
    int testFind(int);
};

#endif