#include "PuzzleGame.hpp"

int PuzzleGame::find(int sval){
  for(int i=0;i<BSZ2;i++){
    if(board[i]==sval){
      return i;
    }
  }
  return -1;
}

void PuzzleGame::randomizeBoard(){
  srand(time(NULL));//seed generator
  for(int i=0;i<BSZ2;i++){
    board[i]=-1;
  }
  for(int i=0;i<BSZ2;i++){
    bool fixed=false;
    while(!fixed){
      int fix=rand()%BSZ2;
      if(board[fix==-1]){
        board[fix]=i;
        fixed=true;
      }
    }
  }
}