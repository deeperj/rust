#include <assert.h>
#include "PuzzleGame.hpp"
#include "Test.h"
#include "expect.h"

Test::~Test(){
  delete game;
}
Test::Test(){
  game=new PuzzleGame();
}
bool Test::getOk(){return ok;}

int test_find(int sv){
    Test t;
    return t.testFind(sv);
}

void Test::testFind2(){
    describe("test PuzzleGame::find()", [] {
        describe("calls PuzzleGame::find(int) and returns an index or -1", [] {
        it("should return the index of value set in Test::Find(int) ",[] {
            expect(test_find(0)).toBe(4);
        });
        });
    });
}
int Test::testFind(int sv){
    game->board[4]=0;
    return game->find(sv);
}

void Test::testall(){
    testFind2();
    testSummary();
}