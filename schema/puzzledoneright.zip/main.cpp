#include "PuzzleGame.hpp"
#include "Test.h"

int main() {
  //std::cout << "Hello World!\n";
  Test t;
  t.testall();
}