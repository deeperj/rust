namespace VideoLibraryFramework
{
    public class Customer
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}