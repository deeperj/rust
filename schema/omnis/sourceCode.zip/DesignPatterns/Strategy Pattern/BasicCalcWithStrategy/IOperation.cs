namespace BasicCalc
{
    public interface IOperation
    {
        string Name { get; }
    }
}