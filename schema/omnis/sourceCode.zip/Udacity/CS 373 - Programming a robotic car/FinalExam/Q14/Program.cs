﻿using System;

namespace Q14
{
    public class Program
    {
        private static Random random = new Random((int)DateTime.Now.Ticks);

        public static void Main(string[] args)
        {
            const int total = 100000000;
            var r = new[] { 0, 0, 0, 0 };
            var count = 0;

            for (int k=0; k<total; ++k)
            {
                r[0] = 0; r[1] = 0; r[2] = 0; r[3] = 0;

                for (int i = 0; i < 12; ++i)
                {
                    r[random.Next(0, 4)]++;
                }

                if (r[0] == 0 || r[1] == 0 || r[2] == 0 || r[3] == 0) count++;
            }

            Console.Write("Prob = {0}", 1 - count / (double) total);
            Console.ReadLine();
        }
    }
}
