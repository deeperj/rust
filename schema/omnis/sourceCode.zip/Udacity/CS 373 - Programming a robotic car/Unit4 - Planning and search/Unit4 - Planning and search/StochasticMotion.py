# --------------
# USER INSTRUCTIONS
#
# Write a function called stochastic_value that 
# takes no input and RETURNS two grids. The
# first grid, value, should contain the computed
# value of each cell as shown in the video. The
# second grid, policy, should contain the optimum
# policy for each cell.
#
# Stay tuned for a homework help video! This should
# be available by Thursday and will be visible
# in the course content tab.
#
# Good luck! Keep learning!
#
# --------------
# GRADING NOTES
#
# We will be calling your stochastic_value function
# with several different grids and different values
# of success_prob, collision_cost, and cost_step.
# In order to be marked correct, your function must
# RETURN (it does not have to print) two grids,
# value and policy.
#
# When grading your value grid, we will compare the
# value of each cell with the true value according
# to this model. If your answer for each cell
# is sufficiently close to the correct answer
# (within 0.001), you will be marked as correct.
#
# NOTE: Please do not modify the values of grid,
# success_prob, collision_cost, or cost_step inside
# your function. Doing so could result in your
# submission being inappropriately marked as incorrect.

# -------------
# GLOBAL VARIABLES
#
# You may modify these variables for testing
# purposes, but you should only modify them here.
# Do NOT modify them inside your stochastic_value
# function.

grid = [[0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 0, 0, 0],
        [0, 1, 1, 0]]
       
goal = [0, len(grid[0])-1] # Goal is in top right corner


delta = [[-1, 0 ], # go up
         [ 0, -1], # go left
         [ 1, 0 ], # go down
         [ 0, 1 ]] # go right

delta_name = ['^', '<', 'v', '>'] # Use these when creating your policy grid.

success_prob = 0.5                      
failure_prob = (1.0 - success_prob)/2.0 # Probability(stepping left) = prob(stepping right) = failure_prob
collision_cost = 100                    
cost_step = 1        
                     

############## INSERT/MODIFY YOUR CODE BELOW ##################
#
# You may modify the code below if you want, but remember that
# your function must...
#
# 1) ...be called stochastic_value().
# 2) ...NOT take any arguments.
# 3) ...return two grids: FIRST value and THEN policy.

def getValue(value, y, x):
    if x >= 0 and x < len(grid[0]) and y >= 0 and y < len(grid):
        if (grid[y][x] == 1):
            return collision_cost
        else:
            return value[y][x]
    else:
        return collision_cost

def stochastic_value():
    value = [[1000.0 for row in range(len(grid[0]))] for col in range(len(grid))]
    policy = [[' ' for row in range(len(grid[0]))] for col in range(len(grid))]
    
    value[goal[0]][goal[1]] = 0
    policy[goal[0]][goal[1]] = '*'

    updated = True
    while updated:
        updated = False
        for x in range(len(grid[0])):
            for y in range(len(grid)):
                for i in range(len(delta)):
                    xs = x + delta[i][1]
                    ys = y + delta[i][0]
                    xf1 = x + delta[(i-1)%4][1]
                    yf1 = y + delta[(i-1)%4][0]
                    xf2 = x + delta[(i+1)%4][1]
                    yf2 = y + delta[(i+1)%4][0]
                    if (grid[y][x] == 1): continue
                    newValue = success_prob * getValue(value, ys, xs) + \
                               failure_prob * getValue(value, yf1, xf1) + \
                               failure_prob * getValue(value, yf2, xf2) + \
                               cost_step
                    if value[y][x] > newValue:
                        value[y][x] = newValue
                        policy[y][x] = delta_name[i]
                        updated = True

    return value, policy

value, policy = stochastic_value()

for i in range(len(value)):
    print value[i]

for i in range(len(policy)):
    print policy[i]

raw_input()