﻿
using System;
using System.Collections.Generic;

namespace SortingStability
{
    public class Person
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public int Count { get; set; }

        public override string ToString()
        {
            return string.Format("{0}\t{1}\t{2}", Name, Surname, Count);
        }
    }

    class Program
    {
        static void Main()
        {
            var products = new List<Person>
                {
                    new Person {Name = "Andrea", Surname = "Angella", Count = 5},
                    new Person {Name = "Michela", Surname = "Tassi", Count = 10},
                    new Person {Name = "Andrea", Surname = "Mancini", Count = 3},
                    new Person {Name = "Franco", Surname = "Angella", Count = 10},
                    new Person {Name = "AnnaMaria", Surname = "Simonelli", Count = 6},
                    new Person {Name = "Andrea", Surname = "Ricci", Count = 8},
                };

            products.Sort((p1, p2) => string.CompareOrdinal(p1.Name, p2.Name));

            foreach (var product in products)
            {
                Console.WriteLine(product);
            }

            Console.ReadKey();
        }
    }
}
