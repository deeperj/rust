﻿using System;
using NUnit.Framework;
using NespressoOrderHelper;

namespace Person_specs
{
    [TestFixture]
    public class SingleDrink
    {
        [Test]
        public void Default()
        {
            var p = new Person().Drink(Capsule.Arpeggio);

            Assert.AreEqual(1, p.Preferences.Count);
            Assert.AreEqual(1, p.Preferences[Capsule.Arpeggio].Quantity);
            Assert.AreEqual(DateTime.MinValue, p.Preferences[Capsule.Arpeggio].FromDate);
            Assert.AreEqual(DateTime.MaxValue, p.Preferences[Capsule.Arpeggio].ToDate);
        }

        [Test]
        public void Quantity()
        {
            var p = new Person().Drink(Capsule.Arpeggio).Quantity(2);

            Assert.AreEqual(1, p.Preferences.Count);
            Assert.AreEqual(2, p.Preferences[Capsule.Arpeggio].Quantity);
            Assert.AreEqual(DateTime.MinValue, p.Preferences[Capsule.Arpeggio].FromDate);
            Assert.AreEqual(DateTime.MaxValue, p.Preferences[Capsule.Arpeggio].ToDate);
        }

        [Test]
        public void Quantity_invalid()
        {
            Assert.Throws<InvalidOperationException>(() => new Person().Quantity(2));
        }

        [Test]
        public void FromDate_invalid()
        {
            Assert.Throws<InvalidOperationException>(() => new Person().From(DateTime.Now));
        }

        [Test]
        public void ToDate_invalid()
        {
            Assert.Throws<InvalidOperationException>(() => new Person().To(DateTime.Now));
        }

        [Test]
        public void Quantity_and_date_range()
        {
            var fromDate = new DateTime(2012, 7, 1);
            var toDate = new DateTime(2012, 7, 10);

            var p = new Person().Drink(Capsule.Arpeggio).Quantity(2).From(fromDate).To(toDate);

            Assert.AreEqual(1, p.Preferences.Count);
            Assert.AreEqual(2, p.Preferences[Capsule.Arpeggio].Quantity);
            Assert.AreEqual(fromDate, p.Preferences[Capsule.Arpeggio].FromDate);
            Assert.AreEqual(toDate, p.Preferences[Capsule.Arpeggio].ToDate);
        }
    }

    [TestFixture]
    public class Multiple_drinks
    {
        [Test]
        public void Two_default()
        {
            var p = new Person().Drink(Capsule.Arpeggio).Drink(Capsule.Ristretto);

            Assert.AreEqual(2, p.Preferences.Count);

            Assert.AreEqual(1, p.Preferences[Capsule.Arpeggio].Quantity);
            Assert.AreEqual(DateTime.MinValue, p.Preferences[Capsule.Arpeggio].FromDate);
            Assert.AreEqual(DateTime.MaxValue, p.Preferences[Capsule.Arpeggio].ToDate);

            Assert.AreEqual(1, p.Preferences[Capsule.Ristretto].Quantity);
            Assert.AreEqual(DateTime.MinValue, p.Preferences[Capsule.Ristretto].FromDate);
            Assert.AreEqual(DateTime.MaxValue, p.Preferences[Capsule.Ristretto].ToDate);
        }

        [Test]
        public void Two_custom()
        {
            var fromDate = new DateTime(2012, 7, 1);
            var toDate = new DateTime(2012, 7, 10);

            var p = new Person().Drink(Capsule.Arpeggio).Quantity(2)
                                .Drink(Capsule.Decaffeinato).Quantity(1).From(fromDate).To(toDate);

            Assert.AreEqual(2, p.Preferences.Count);

            Assert.AreEqual(2, p.Preferences[Capsule.Arpeggio].Quantity);
            Assert.AreEqual(DateTime.MinValue, p.Preferences[Capsule.Arpeggio].FromDate);
            Assert.AreEqual(DateTime.MaxValue, p.Preferences[Capsule.Arpeggio].ToDate);

            Assert.AreEqual(1, p.Preferences[Capsule.Decaffeinato].Quantity);
            Assert.AreEqual(fromDate, p.Preferences[Capsule.Decaffeinato].FromDate);
            Assert.AreEqual(toDate, p.Preferences[Capsule.Decaffeinato].ToDate);
        }
    }
}

namespace Order_spec
{
    [TestFixture]
    public class Calculate
    {
        [Test]
        public void Test()
        {
            var andrea = new Person().Drink(Capsule.Volluto).Quantity(2)
                                     .Drink(Capsule.Decaffeinato).Quantity(1);

            var michela = new Person().Drink(Capsule.Arpeggio).Quantity(2)
                                      .Drink(Capsule.Decaffeinato).Quantity(1);

            var annamaria = new Person().Drink(Capsule.Arpeggio).Quantity(2)
                                        .Drink(Capsule.Decaffeinato).Quantity(1);


        }
    }

}