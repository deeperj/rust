using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace NespressoOrderHelper
{
    public class Person
    {
        private readonly Dictionary<Capsule, Habit> preferences;
        private Capsule selectedCapsule;
        protected DateTime FromDate { get; set; }
        protected DateTime ToDate { get; set; }

        public Person()
        {
            preferences = new Dictionary<Capsule, Habit>();
        }

        public ReadOnlyDictionary<Capsule, Habit> Preferences
        {
            get { return new ReadOnlyDictionary<Capsule, Habit>(preferences); }
        }

        public Person Drink(Capsule capsule)
        {
            selectedCapsule = capsule;

            preferences[selectedCapsule] = new Habit();

            return this;
        }

        public Person Quantity(int quantity)
        {
            if (selectedCapsule == null)
                throw new InvalidOperationException("Set the drink first.");

            preferences[selectedCapsule].Quantity = quantity;
            
            return this;
        }

        public Person From(DateTime fromDate)
        {
            FromDate = fromDate;

            return this;
        }

        public Person To(DateTime toDate)
        {
            ToDate = toDate;

            return this;
        }

    }
}