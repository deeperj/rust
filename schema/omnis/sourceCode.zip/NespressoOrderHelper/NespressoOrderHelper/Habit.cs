using System;

namespace NespressoOrderHelper
{
    public class Habit
    {
        public int Quantity { get; set; }

        public Habit()
        {
            Quantity = 1;
            FromDate = DateTime.MinValue;
            ToDate = DateTime.MaxValue;
        }
    }
}