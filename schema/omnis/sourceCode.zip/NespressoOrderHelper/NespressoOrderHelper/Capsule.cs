namespace NespressoOrderHelper
{
    public class Capsule
    {
        // Espresso Blends
        public static Capsule Ristretto = new Capsule();
        public static Capsule Arpeggio = new Capsule();
        public static Capsule Roma = new Capsule();
        public static Capsule Livanto = new Capsule();
        public static Capsule Capriccio = new Capsule();
        public static Capsule Volluto = new Capsule();
        public static Capsule Cosi = new Capsule();

        // Pure Origin Espressos
        public static Capsule IndriyaFromIndia = new Capsule();
        public static Capsule RosabayaDeColombia = new Capsule();
        public static Capsule DulsaoDoBrasil = new Capsule();

        // Decaffeinated
        public static Capsule DecaffeinatoIntenso = new Capsule();
        public static Capsule DecaffeinatoLungo = new Capsule();
        public static Capsule Decaffeinato = new Capsule();

        // Lungos
        public static Capsule FortissioLungo = new Capsule();
        public static Capsule VivaltoLungo = new Capsule();
        public static Capsule FinezzoLungo = new Capsule();

        private Capsule()
        {
        }
    }
}