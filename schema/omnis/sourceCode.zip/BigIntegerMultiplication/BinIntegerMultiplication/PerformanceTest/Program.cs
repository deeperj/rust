﻿using System;
using System.Diagnostics;
using System.Numerics;
using System.Text;
using BinIntegerMultiplication;

namespace PerformanceTest
{
    public class Program
    {
        private static Random random = new Random((int)DateTime.Now.Ticks);

        public static string GetRandomBigNumber(int n)
        {
            var sb = new StringBuilder(n);

            for (int i = 0; i < n; ++i)
            {
                sb.Append(random.Next(10));
            }

            return sb.ToString();
        }

        public static void Main(string[] args)
        {
            var num1 = GetRandomBigNumber(1000);
            var num2 = GetRandomBigNumber(1000);

            var bigNum1 = BigInteger.Parse(num1);
            var bigNum2 = BigInteger.Parse(num2);

            var stopWatch = new Stopwatch();
            stopWatch.Start();

            string frameworkResult = (bigNum1 * bigNum2).ToString();
            Console.WriteLine(frameworkResult);

            stopWatch.Stop();
            Console.WriteLine();
            long frameworkMs = stopWatch.ElapsedMilliseconds;
            Console.WriteLine();

            stopWatch.Reset();

            var myBigNum1 = new MyBigInteger(num1);
            var myBigNum2 = new MyBigInteger(num2);
            
            stopWatch.Start();

            string myResult = (myBigNum1 * myBigNum2).ToString();
            Console.WriteLine(myResult);

            stopWatch.Stop();
            Console.WriteLine();
            long myMs = stopWatch.ElapsedMilliseconds;

            Console.WriteLine();
            Console.WriteLine("Same result? {0}", myResult == frameworkResult);
            Console.WriteLine("Framework: {0}\tms", frameworkMs);
            Console.WriteLine("     Mine: {0}\tms", myMs);

            Console.ReadKey();
        }
    }
}
