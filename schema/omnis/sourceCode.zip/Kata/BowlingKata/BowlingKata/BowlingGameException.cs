using System;

namespace BowlingKata
{
    public class BowlingGameException : Exception
    {
        public BowlingGameException()
        {
        }

        public BowlingGameException(string message) : base(message)
        {
        }
    }
}