﻿namespace BowlingKata
{
    public class TenthFrame : Frame
    {
        /// <summary>
        /// Returns a representation of the Frame as a string.
        /// </summary>
        public override string ToString()
        {
            if (IsStrike && NextFrame.IsStrike)
            {
                return "XX" + NextFrame.NextFrame.ToString()[0];
            }

            if (IsStrike)
            {
                return "X" + NextFrame;
            }

            if (IsSpare)
            {
                return string.Format("{0}/{1}", Shots[0], NextFrame.ToString()[0]);
            }

            return base.ToString();
        }
    }
}
