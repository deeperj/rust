﻿namespace CoffeeMaker.API
{
    public interface ICoffeeMaker
    {
        /// <summary>
        /// Gets the status of the warmer-plate sensor.
        /// </summary>
        /// <returns>
        /// A <see cref="WarmerPlateStatus" /> value that represents a warmer-plate sensor status.
        /// </returns>
        /// <remarks>
        /// Warmer-plate sensor detects the presence of the pot and whether it has coffee in it.
        /// </remarks>
        WarmerPlateStatus GetWarmerPlateStatus();

        /// <summary>
        /// Gets the status of the boiler switch.
        /// </summary>
        /// <returns>
        /// A <see cref="BoilerStatus" /> value that represents a boiler switch status.
        /// </returns>
        /// <remarks>
        /// The boiler switch is a float switch that detects if there is more than 1/2 cup of water in the boiler.
        /// </remarks>
        BoilerStatus GetBoilerStatus();

        /// <summary>
        /// Gets the status if of the brew button.
        /// </summary>
        /// <returns>
        /// A <see cref="BrewButtonStatus" /> value that represents a brew button status.
        /// </returns>
        /// <remarks>
        /// The brew button is a momentary switch that remembers its state.
        /// Each call to this function returns the remembered state and then resets that state to <see cref="BrewButtonStatus.NOT_PUSHED" />.
        /// Thus, even if this function is polled at a very slow rate, it will still detect when the brew button is pushed.
        /// </remarks>
        BrewButtonStatus GetBrewButtonStatus();

        /// <summary>
        /// Turns the heating element in the boiler on or off.
        /// </summary>
        /// <param name="state">The state for the boiler.</param>
        void SetBoilerState(BoilerState state);

        /// <summary>
        /// Turns the heating element in the warmer plate on or off.
        /// </summary>
        /// <param name="state">The state for the warmer.</param>
        void SetWarmerState(WarmerState state);

        /// <summary>
        /// Turns the indicator light on or off.
        /// </summary>
        /// <param name="state">The state for indicator light.</param>
        /// <remarks>
        /// The indicator light should be turned on at the end of the brewing cycle.
        /// It should be turned off when the user presses the brew button.
        /// </remarks>
        void SetIndicatorState(IndicatorState state);

        /// <summary>
        /// Opens and closes the pressure-relief valve.
        /// </summary>
        /// <param name="state">The state for pressure-relief valve.</param>
        /// <remarks>
        /// When this valve is closed, steam pressure in the boiler will force hot water to spray out over the coffee filter.
        /// When the valve is open, the steam in the boiler escapes into the environment, and the water in the boiler will not spray out over the filter.
        /// </remarks>
        void SetReliefValveState(ReliefValveState state);
    }
}