﻿namespace CoffeeMaker.API
{
    public enum IndicatorState
    {
        ON,
        OFF
    }
}