﻿namespace CoffeeMaker.API
{
    public enum WarmerState
    {
        ON,
        OFF
    }
}