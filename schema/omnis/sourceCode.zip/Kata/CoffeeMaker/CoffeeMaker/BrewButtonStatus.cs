﻿namespace CoffeeMaker.API
{
    public enum BrewButtonStatus
    {
        PUSHED,
        NOT_PUSHED
    }
}