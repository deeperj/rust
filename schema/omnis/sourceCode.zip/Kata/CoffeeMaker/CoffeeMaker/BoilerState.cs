﻿namespace CoffeeMaker.API
{
    public enum BoilerState
    {
        ON,
        OFF
    }
}