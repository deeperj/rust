﻿namespace CoffeeMaker.API
{
    public enum ReliefValveState
    {
        OPEN,
        CLOSED
    }
}