﻿namespace CoffeeMaker.API
{
    public enum BoilerStatus
    {
        EMPTY,
        NOT_EMPTY
    }
}