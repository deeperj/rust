﻿using System;

namespace KataBowling
{
    public class Frame
    {
        private string frame;

        public Frame(string frame)
        {
            this.frame = frame;

            IsStrike = false;
            IsSpare = false;
            Score = 10;

            if (frame[0] == 'X')
            {
                IsStrike = true;
                IsSpare = false;
                Score = 10;
                return;
            }
            
            if (frame[1] == '/')
            {
                IsStrike = false;
                IsSpare = true;
                Score = 10;
                return;
            }

            IsStrike = false;
            IsSpare = false;
            Score = GetRollScore(frame[0]) + GetRollScore(frame[1]);
        }
        
        private static int GetRollScore(char roll)
        {
            return roll == '-' ? 0 : Int32.Parse("" + roll);
        }

        public bool IsStrike { get; private set; }
        public bool IsSpare { get; private set; }
        public int Score { get; private set; }

        public int FirstRollScore 
        { 
            get
            {
                return IsStrike ? 10 : GetRollScore(frame[0]);
            }
        }

        public override bool Equals(object obj)
        {
            return ToString() == obj.ToString();
        }

        public override string ToString()
        {
            return frame;
        }
    }
}