﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace KataBowling
{
    [TestFixture]
    public class FrameTokenizerTest
    {
        [Test]
        public void Test()
        {
            var frameTokenizer = new FrameTokenizer("--546/XX1/-/-49---");

            Assert.AreEqual("--", frameTokenizer.GetNextFrame().ToString());
            Assert.AreEqual("54", frameTokenizer.GetNextFrame().ToString());
            Assert.AreEqual("6/", frameTokenizer.GetNextFrame().ToString());
            Assert.AreEqual("X", frameTokenizer.GetNextFrame().ToString());
            Assert.AreEqual("X", frameTokenizer.GetNextFrame().ToString());
            Assert.AreEqual("1/", frameTokenizer.GetNextFrame().ToString());
            Assert.AreEqual("-/", frameTokenizer.GetNextFrame().ToString());
            Assert.AreEqual("-4", frameTokenizer.GetNextFrame().ToString());
            Assert.AreEqual("9-", frameTokenizer.GetNextFrame().ToString());
            Assert.AreEqual("--", frameTokenizer.GetNextFrame().ToString());

            Assert.AreEqual(null, frameTokenizer.GetNextFrame());
        }

        [Test]
        public void Tests()
        {
            var frameTokenizer = new FrameTokenizer("--546/XX1/-/-49---");
            
            var frames = frameTokenizer.GetAllFrames();
            var expectedFrames = new List<Frame>
                                 {
                                     new Frame("--"),
                                     new Frame("54"),
                                     new Frame("6/"),
                                     new Frame("X"),
                                     new Frame("X"),
                                     new Frame("1/"),
                                     new Frame("-/"),
                                     new Frame("-4"),
                                     new Frame("9-"),
                                     new Frame("--"),
                                 };

            CollectionAssert.AreEqual(frames, expectedFrames);
        }
    }
}
