﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace KataBowling
{
    [TestFixture]
    class FrameTest
    {
        [Test]
        public void EmptyRolls()
        {
            var frame = new Frame("--");

            Assert.AreEqual(false, frame.IsStrike);
            Assert.AreEqual(false, frame.IsSpare);
            Assert.AreEqual(0, frame.FirstRollScore);
            Assert.AreEqual(0, frame.Score);
            Assert.AreEqual("--", frame.ToString());
        }

        [Test]
        public void SimpleRolls()
        {
            var frame = new Frame("23");

            Assert.AreEqual(false, frame.IsStrike);
            Assert.AreEqual(false, frame.IsSpare);
            Assert.AreEqual(2, frame.FirstRollScore);
            Assert.AreEqual(5, frame.Score);
            Assert.AreEqual("23", frame.ToString());
        }

        [Test]
        public void Spare()
        {
            var frame = new Frame("6/");

            Assert.AreEqual(false, frame.IsStrike);
            Assert.AreEqual(true, frame.IsSpare);
            Assert.AreEqual(6, frame.FirstRollScore);
            Assert.AreEqual(10, frame.Score);
            Assert.AreEqual("6/", frame.ToString());
        }

        [Test]
        public void Strike()
        {
            var frame = new Frame("X");

            Assert.AreEqual(true, frame.IsStrike);
            Assert.AreEqual(false, frame.IsSpare);
            Assert.AreEqual(10, frame.FirstRollScore);
            Assert.AreEqual(10, frame.Score);
            Assert.AreEqual("X", frame.ToString());
        }
    }
}
