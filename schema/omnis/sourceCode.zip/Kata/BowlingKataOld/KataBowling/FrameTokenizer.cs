﻿using System;
using System.Collections.Generic;

namespace KataBowling
{
    public class FrameTokenizer
    {
        private string rolls;

        public FrameTokenizer(string rolls)
        {
            this.rolls = rolls;
        }

        public Frame GetNextFrame()
        {
            if (string.IsNullOrEmpty(rolls))
            {
                return null;
            }

            Frame result;

            if (rolls[0] == 'X')
            {
                rolls = rolls.Substring(1);
                result = new Frame("X");
            }
            else
            {
                if (rolls.Length == 1)
                {
                    result = new Frame(rolls + "-");
                    rolls = "";
                }
                else
                {
                    result = new Frame(rolls.Substring(0, 2));
                    rolls = rolls.Substring(2);                                        
                }
            }

            return result;
        }

        public List<Frame> GetAllFrames()
        {
            var frames = new List<Frame>();
            Frame frame;

            do
            {
                frame = GetNextFrame();

                if (frame != null)
                {
                    frames.Add(frame);
                }
            }
            while (frame != null);

            return frames;
        }
    }
}