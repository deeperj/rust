﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;

namespace KataBowling
{
    [TestFixture]
    class BowlingCalculatorTests
    {
        [Test]
        public void AllStrikes()
        {
            Assert.AreEqual(300, BowlingCalculator.GetScore("XXXXXXXXXXXX"));
        }

        [Test]
        public void All_Nine()
        {
            Assert.AreEqual(90, BowlingCalculator.GetScore("9-9-9-9-9-9-9-9-9-9-"));           
        }

        [Test]
        public void All_SparesWithFive()
        {
            Assert.AreEqual(150, BowlingCalculator.GetScore("5/5/5/5/5/5/5/5/5/5/5"));           
        }

        [Test]
        public void All_NoStrikesAndNoSpares()
        {
            Assert.AreEqual(51, BowlingCalculator.GetScore("--1--2-3-4527-9-6354"));
        }

        [Test]
        public void All_Strike_StrikeStrike()
        {
            Assert.AreEqual(30 + 20 + 10, BowlingCalculator.GetScore("XXX--------------"));
        }

        [Test]
        public void All_Strike_StrikeSpare()
        {
            Assert.AreEqual(20 + 20 + 10, BowlingCalculator.GetScore("XX-/--------------"));
        }

        [Test]
        public void All_Strike_StrikeNormal()
        {
            Assert.AreEqual(23 + 15 + 5, BowlingCalculator.GetScore("XX32--------------"));
        }

        [Test]
        public void All_Strike_SpareNormal()
        {
            Assert.AreEqual(20 + 16 + 7, BowlingCalculator.GetScore("X3/61--------------"));
        }

        [Test]
        public void All_Strike_SpareSpare()
        {
            Assert.AreEqual(20 + 16 + 10, BowlingCalculator.GetScore("X3/6/--------------"));
        }

        [Test]
        public void All_Strike_NormalNormal()
        {
            Assert.AreEqual(15 + 5 + 9, BowlingCalculator.GetScore("X2345--------------"));
        }
    }
}
