﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KataBowling
{
    public class BowlingCalculator
    {
        public static int GetScore(string rolls)
        {
            int res = 0;

            var frameTokenizer = new FrameTokenizer(rolls);
            var frames = frameTokenizer.GetAllFrames();

            for (int i = 0; i < 10; ++i)
            {
                var frame = frames[i];

                if (frame.IsStrike)
                {
                    var frame1 = frames[i + 1];

                    if (frame1.IsStrike)
                    {
                        var frame2 = frames[i + 2];

                        if (frame2.IsStrike)
                        {
                            res += 30;
                        }
                        else
                        {
                            res += frame.Score + frame1.Score + frame2.FirstRollScore;
                        }
                    }
                    else
                    {
                        res += frame.Score + frame1.Score;
                    }
                }
                else if (frame.IsSpare)
                {
                    res += frame.Score + frames[i + 1].FirstRollScore;                    
                }
                else
                {
                    res += frame.Score;
                }
            }

            return res;
        }
    }
}
