﻿using NUnit.Framework;
using TaxCalculationChallenge;

namespace TaxCalculationChallengeTests
{
    [TestFixture]
    public class IsraelTaxCalculatorTests
    {
        private TaxCalculator taxCalculator;

        [SetUp]
        public void SetUp()
        {
            taxCalculator = TaxCalculator.CreateIsraelTaxCalculator();    
        }

        [Test]
        public void ZeroTax()
        {
            Assert.AreEqual(0, taxCalculator.Calculate(0));
        }

        [Test]
        public void TaxCalculatorReuse()
        {
            const decimal amount1 = 5000m;
            const decimal expectedTax1 = amount1 * 10 / 100;

            const decimal amount2 = 5800m;
            const decimal expectedTax2 =
                5070m * (10m / 100) +
                (amount2 - 5070) * (14m / 100);

            Assert.AreEqual(expectedTax1, taxCalculator.Calculate(amount1));
            Assert.AreEqual(expectedTax2, taxCalculator.Calculate(amount2));
        }

        [Test]
        public void Rate_0_To_5070()
        {
            const decimal amount = 5000;
            const decimal expectedTax = amount * 10 / 100;

            Assert.AreEqual(expectedTax, taxCalculator.Calculate(amount));            
        }

        [Test]
        public void Rate_5071_UpTo_8660()
        {
            const decimal amount = 5800;
            const decimal expectedTax =
                5070m * (10m / 100) +
                (amount - 5070) * (14m / 100);

            Assert.AreEqual(
                expectedTax,
                taxCalculator.Calculate(amount));
        }

        [Test]
        public void Rate_8661_UpTo_14070()
        {
            const decimal amount = 9000;
            const decimal expectedTax =
                5070m * (10m / 100) +
                (8660 - 5070) * (14m / 100) +
                (amount - 8660) * (23m / 100);

            Assert.AreEqual(expectedTax, taxCalculator.Calculate(amount));
        }

        [Test]
        public void Rate_14071_UpTo_21240()
        {
            const decimal amount = 15000;
            const decimal expectedTax =
                5070m * (10m / 100) +
                (8660 - 5070) * (14m / 100) +
                (14070 - 8660) * (23m / 100) +
                (amount - 14070) * (30m / 100);

            Assert.AreEqual(expectedTax, taxCalculator.Calculate(amount));
        }

        [Test]
        public void Rate_21241_UpTo_40230()
        {
            const decimal amount = 30000;
            const decimal expectedTax =
                5070m * (10m / 100) +
                (8660 - 5070) * (14m / 100) +
                (14070 - 8660) * (23m / 100) +
                (21240 - 14070) * (30m / 100) +
                (amount - 21240) * (33m / 100);

            Assert.AreEqual(expectedTax, taxCalculator.Calculate(amount));
        }

        [Test]
        public void Rate_Higher_than_40230()
        {
            const decimal amount = 50000;
            const decimal expectedTax =
                5070m * (10m / 100) +
                (8660 - 5070) * (14m / 100) +
                (14070 - 8660) * (23m / 100) +
                (21240 - 14070) * (30m / 100) +
                (40230 - 21240) * (33m / 100) +
                (amount - 40230) * (45m / 100);

            Assert.AreEqual(expectedTax, taxCalculator.Calculate(amount));
        }
    }
}
