﻿
using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace CSharp5
{
    public class PerformanceCounters
    {
        public static void Start()
        {
            //ReadCategoriesAndCounters();
            //ReadPerformanceCounter();
            CreatePerformanceCounter();
        }

        private static void CreatePerformanceCounter()
        {
            string category = "Andreaan";
            string oddNumbersPc = "Odd Numbers";
            string tensNumbersPc = "SquaredNumbersPc";

            if (!PerformanceCounterCategory.Exists(category))
            {
                CounterCreationDataCollection cd = new CounterCreationDataCollection();
                cd.Add(new CounterCreationData(oddNumbersPc, oddNumbersPc, PerformanceCounterType.NumberOfItems32));
                cd.Add(new CounterCreationData(tensNumbersPc, tensNumbersPc, PerformanceCounterType.NumberOfItems32));

                PerformanceCounterCategory.Create(category, "Andreaan Description", PerformanceCounterCategoryType.SingleInstance, cd);
            }

            using (PerformanceCounter onpc = new PerformanceCounter(category, oddNumbersPc, "", false))
            using (PerformanceCounter tpc = new PerformanceCounter(category, tensNumbersPc, "", false))
            {
                onpc.RawValue = 0;
                tpc.RawValue = 0;

                for (int i = 0; i < 2 * 60; i++)
                {
                    if (i % 2 == 1) onpc.Increment();
                    if (i % 10 == 0) tpc.Increment();

                    Thread.Sleep(500);
                }
            }
        }

        private static void ReadPerformanceCounter()
        {
            var processName = Process.GetCurrentProcess().ProcessName;

            int[][] v = new int[10][];

            using (PerformanceCounter pc = new PerformanceCounter("Process", "Private Bytes", processName))
            {
                for (int i = 0; i < 100; i++)
                {
                    Console.WriteLine(pc.NextValue() / 1024 / 1024 + " Mbytes");

                    if (i % 10 == 0)
                    {
                        v[i / 10] = new int[1000000];
                    }

                    Thread.Sleep(500);
                }
            }
        }

        private static void ReadCategoriesAndCounters()
        {
            var categories = PerformanceCounterCategory.GetCategories();

            foreach (var category in categories)
            {
                Console.WriteLine(category.CategoryName);

                var instanceNames = category.GetInstanceNames();

                if (instanceNames.Length == 0)
                {
                    foreach (PerformanceCounter counter in category.GetCounters())
                    {
                        Console.WriteLine("  Counter: " + counter.CounterName);
                    }
                }
                else
                {
                    foreach (var instanceName in instanceNames)
                    {
                        Console.WriteLine("  Instance: " + instanceName);

                        if (category.InstanceExists(instanceName))
                        {
                            foreach (PerformanceCounter counter in category.GetCounters(instanceName))
                            {
                                Console.WriteLine("    Counter: " + counter.CounterName);
                            }
                        }
                    }
                }
            }
        }
    }
}