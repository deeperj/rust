﻿using System;
using System.Dynamic;

namespace CSharp5
{
    class Dynamic
    {
        public class Student : DynamicObject
        {
            public override bool TryInvokeMember(InvokeMemberBinder binder, object[] args, out object result)
            {
                if (binder.Name == "Name")
                {
                    result = "Andrea";
                }
                else if (binder.Name == "Surname")
                {
                    result = "Angella";
                }
                else
                {
                    result = "<unknown>";                    
                }

                return true;
            }
        }

        public static void Start()
        {
            dynamic student = new Student();

            Console.WriteLine(student.Name());
            Console.WriteLine(student.Surname());
            Console.WriteLine(student.Age());

            dynamic expandObject = new ExpandoObject();
            expandObject.Name = "Andrea";
            expandObject.Surname = "Angella";
            expandObject.Age = 28;

            Console.WriteLine("{0} {1} {2}", expandObject.Name, expandObject.Surname, expandObject.Age);
        }
    }
}