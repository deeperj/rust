﻿using System;
using System.Reflection;

namespace CSharp5
{
    public class Reflection
    {
        public static void Start()
        {
            string s = "Andrea";
            Type st = s.GetType();

            Console.WriteLine("IsPublic:" + st.IsPublic);
            Console.WriteLine("IsClass:" + st.IsClass);
            Console.WriteLine("IsValueType:" + st.IsValueType);
            Console.WriteLine("IsSerializable:" + st.IsSerializable);
            Console.WriteLine("Namespace:" + st.Namespace);
            Console.WriteLine("Assembly:" + st.Assembly);
            Console.WriteLine("AssemblyQualifiedName:" + st.AssemblyQualifiedName);
            Console.WriteLine("BaseType:" + st.BaseType);

            Console.WriteLine("\nInterfaces...\n");
            foreach (Type t in st.GetInterfaces())
            {
                Console.WriteLine(t.ToString());
            }

            Console.WriteLine("\nInstance members...\n");
            foreach (MemberInfo m in st.GetMembers(BindingFlags.Instance))
            {
                Console.WriteLine(m.ToString());
            }

            Console.WriteLine("\nMethods...\n");
            foreach (MethodInfo method in st.GetMethods())
            {
                Console.WriteLine(method.ToString()); 
            }

            Console.WriteLine("\nProperties...\n");
            foreach (PropertyInfo property in st.GetProperties())
            {
                Console.WriteLine(property.ToString());
            }
        }        
    }
}