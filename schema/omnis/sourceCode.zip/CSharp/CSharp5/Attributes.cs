﻿using System;
using System.Dynamic;

namespace CSharp5
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = true, Inherited = true)]
    public sealed class PowerAttribute : Attribute
    {
        public string Name { get; set; }
    }

    [Power(Name = "Fly")]
    [Power(Name = "Eat")]
    public class A
    {
    }

    [Power(Name = "Sing")]
    public class B : A
    {
        
    }

    public class Attributes
    {
        public static void Start()
        {
            Console.WriteLine("Attributes of A");
            foreach (PowerAttribute attribute in typeof(A).GetCustomAttributes(typeof(PowerAttribute), true))
            {
                Console.WriteLine(attribute.Name);
            }

            Console.WriteLine("\nAttributes of B");
            foreach (PowerAttribute attribute in typeof(B).GetCustomAttributes(typeof(PowerAttribute), true))
            {
                Console.WriteLine(attribute.Name);
            }

            var a = new A();

            Console.WriteLine("\nAttributes of a");
            foreach (PowerAttribute attribute in a.GetType().GetCustomAttributes(typeof(PowerAttribute), true))
            {
                Console.WriteLine(attribute.Name);
            }

            var b = new B();

            Console.WriteLine("\nAttributes of b");
            foreach (PowerAttribute attribute in b.GetType().GetCustomAttributes(typeof(PowerAttribute), true))
            {
                Console.WriteLine(attribute.Name);
            }
        }        
    }
}