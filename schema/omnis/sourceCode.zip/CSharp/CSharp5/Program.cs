﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp5
{
    class Program
    {
        static void Main(string[] args)
        {
            //Dynamic.Start();
            //Attributes.Start();
            //CodeDom.Start();
            //Reflection.Start();
            //Comparable.Start();
            //JsonSerialization.Start();
            //Tracing.Start();
            PerformanceCounters.Start();

            Console.ReadKey();
        }
    }
}
