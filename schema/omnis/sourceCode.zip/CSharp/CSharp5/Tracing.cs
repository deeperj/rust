﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;

namespace CSharp5
{
    public class Tracing
    {
        public static void Start()
        {
            //var ts = new TraceSource("TraceManager")
            //{
            //    Switch =
            //    {
            //        Level = SourceLevels.All
            //    }
            //};
            //ts.Attributes.Add("AutoFlush", "true");
            //ts.Listeners.Remove("Default");
            
            Trace.Listeners.Add(new TextWriterTraceListener("log.txt")
                                {
                                    TraceOutputOptions = TraceOptions.None,
                                    Filter = new EventTypeFilter(SourceLevels.Warning)
                                });

            for (int i = 0; i < 100; i++)
            {
                if (i < 10)
                    Trace.TraceInformation(i.ToString());
                else if (i < 50)
                    Trace.TraceWarning(i.ToString());
                else Trace.TraceError(i.ToString());
            }            

            Trace.Flush();
        }
    }
}