﻿using System;
using System.Collections.Generic;

namespace CSharp5
{
    public class Computer : IComparable, IComparable<Computer>
    {
        public int Memory { get; set; }

        public Computer(int memory)
        {
            Memory = memory;
        }

        public int CompareTo(object obj)
        {
            if (obj == null) return 1;

            Computer other = obj as Computer;
            
            if (other == null)
                return 1;

            return CompareTo(other);
        }

        public int CompareTo(Computer other)
        {
            return Memory - other.Memory;
        }
    }

    public class Comparable
    {
        public static void Start()
        {
            var computers = new List<Computer>
                            {
                                new Computer(50),
                                new Computer(20),
                                new Computer(256),
                                new Computer(26)
                            };

            computers.Sort();

            foreach (var computer in computers)
            {
                Console.WriteLine(computer.Memory);
            }
        }        
    }
}