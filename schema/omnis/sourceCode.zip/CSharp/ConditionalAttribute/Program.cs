﻿using System;
using System.Diagnostics;

    namespace ConditionalAttributeTest
    {
        public class Logger
        {
            public static void Log(string message)
            {
    #if DEBUG
                Console.WriteLine(message);
    #endif
            }
        }

        class Program
        {
            static void Main()
            {
                Console.WriteLine("Test Conditional Attribute");
                Logger.Log("Log1");
                Console.WriteLine("Messaggio1");
                Logger.Log("Log2");
                Console.ReadKey();
            }
        }
    }

