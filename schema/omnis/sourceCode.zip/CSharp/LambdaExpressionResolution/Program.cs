﻿using System;

namespace LambdaExpressionResolution
{
    class Program
    {
        static void Main()
        {
            Action<int> square = x => Console.WriteLine(x * x);

            square(1);
            square(2);

            Console.ReadKey();
        }
    }
}
