﻿using System;
using NUnit.Framework;

namespace DateTimeOffsetExample
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }

    [TestFixture]
    class Tests
    {
        [Test]
        public void TestEquals()
        {
            var dt1 = DateTime.Now;
            var dt2 = DateTime.UtcNow;

            Assert.AreEqual(dt1, dt2);
        }

        [Test]
        public void TestEquals2()
        {
            var dt1 = DateTimeOffset.Now;
            var dt2 = DateTimeOffset.UtcNow;

            Tuple<int, int> a;


            Assert.AreNotEqual(dt1, dt2);
            Assert.AreEqual(-1, (dt1 - dt2).TotalMinutes);
        }
    }
}
