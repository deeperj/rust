﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Contravariance
{
    class Shape
    {
        public int Area { get; set; }
    }

    class Circle : Shape
    {
    }

    class ShapeComparer : IEqualityComparer<Shape>
    {
        public bool Equals(Shape x, Shape y)
        {
            return x.Area == y.Area;
        }

        public int GetHashCode(Shape obj)
        {
            return obj.Area.GetHashCode();
        }
    }

    class Program
    {
        static void Main()
        {
            var circles = new List<Circle> 
                          {
                              new Circle { Area = 1 }, 
                              new Circle { Area = 2 },
                              new Circle { Area = 2 },
                          };

            var distinctCircles = circles.Distinct<Circle>(new ShapeComparer());

            Console.WriteLine(distinctCircles.Count());
        }
    }

}
