﻿using System;
using System.Collections.Generic;

namespace Covariance
{
    class Shape
    {
        public double Area { get; set; }
    }

    class Circle : Shape
    {
    }

    class Program
    {
        static void PrintAreas(IEnumerable<Shape> shapes)
        {
            foreach (var shape in shapes)
            {
                Console.WriteLine("Area: {0}", shape.Area);
            }    
        }

        static void Main(string[] args)
        {
            var circles = new List<Circle> 
                          {
                              new Circle { Area = 1 }, 
                              new Circle { Area = 2 }
                          };
            
            PrintAreas(circles);
            Console.ReadKey();
        }
    }

}
